import { BeneficiariesHero } from "@/components/website/beneficiaries/beneficiaries-hero"
import { BeneficiariesGrid } from "@/components/website/beneficiaries/beneficiaries-grid"
import { BeneficiariesStats } from "@/components/website/beneficiaries/beneficiaries-stats"

export default function BeneficiariesPage() {
  return (
    <div className="pt-20">
      <BeneficiariesHero />
      <BeneficiariesStats />
      <BeneficiariesGrid />
    </div>
  )
}
